# NEXORA Website — Draft v0.1

This is a responsive, English-language static website for the NEXORA concept project.

## Important status notes
- This is a draft website, not proof that a company, token, product, treasury, or investment operation exists.
- The proposed NXR token has **not** been deployed by this package.
- The token allocation is illustrative and must be reviewed before any public use.
- No token price, profit, or investment return is promised.
- The `hello@nexora.example` contact is a placeholder and must be replaced before publishing.
- No wallet address is published on the site; do not describe any wallet as an official treasury until that is deliberately set up and documented.
- Do not add profit-sharing promises or accept public funds until qualified legal advice, risk disclosures, and the actual operating model are in place.

## Preview locally
Open `index.html` in a browser. An internet connection is used for Google Fonts; the layout otherwise works as a static page.

## Publish with GitHub Pages
1. Create or sign in to a GitHub account.
2. Create a new public repository, e.g. `nexora-site`.
3. Upload `index.html`, `styles.css`, and `script.js` to the repository root.
4. In the repository, open **Settings → Pages**.
5. Select **Deploy from a branch**, choose `main` and `/ (root)`, then save.
6. Wait for GitHub Pages to provide the public website URL.

Before publishing, replace the placeholder contact email, review all claims, and add a final legal/privacy notice appropriate to the actual operator and jurisdiction.

## Files
- `index.html` — page content and layout
- `styles.css` — responsive visual design
- `script.js` — mobile navigation and current year
